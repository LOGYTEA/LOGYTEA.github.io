# 示例插件 Hello Demo

ZenFile 插件的最小可用实现，也是新插件的起点。

## 它做什么

启动后向宿主握手（hello），随后每 2.5 秒发一次心跳。
打开 ZenFile「设置 - 插件」，应显示「运行中」。

## 怎么验证真的在跑

面板文字会骗人，看日志：

```bash
grep "\[beat\]" "$TEMP/zenfile_plugins.log" | tail -5
```

看到 `greeted=true` 且 `age_ms` 不持续增长，说明链路是通的。

## 包里有什么

- `plugin.json` —— 插件清单，id 必须与商店条目一致
- `ZenFile.exe` —— **插件就是宿主自己的另一个进程**。
  宿主用 `ZenFile.exe --plugin hello-demo` 拉起它，
  所以这个文件不需要改名，也不需要你再编译出别的可执行文件。

## 做成你自己的插件

1. 改 `plugin.json` 里的 `id`（只能用小写字母、数字、下划线、短横线）
2. 按需申请 `capabilities`
3. 重新打包：zip 根目录下放 `plugin.json` 与 `ZenFile.exe`
4. 上传到商店清单

完整说明见 https://logytea.github.io/zenfile/docs/new-plugin.html
